<?php
/**
 * Created by PhpStorm.
 * User: KATE
 * Date: 10/11/2018
 * Time: 10:30 AM
 */
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title> </title>
    <!-- Favicon-->
    <link rel="icon" href="../favicon.ico" type="image/x-icon">

    <!-- Bootstrap Core Css -->
    <link href="../public/vendors/Metronic/theme/assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
<body class="theme-red" style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif,">
< 
</body>
</html>

