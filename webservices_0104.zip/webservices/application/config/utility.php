<?php
 
function replaceInd($str){
     
    return $str;
}