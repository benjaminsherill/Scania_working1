1. unzip "webservices.zip" and overwrite "webservices" directory to "C:\APM_Setup\htdocs"
2. Test TruckFlasher4_new.exe following previos ReadMe.
