<?php

            // Mysql host
            $mysql["host"] = "localhost";

            // Mysql database name
            $mysql["database"] = "db_dpm21";

            // Your Mysql username for the above database
            $mysql["username"] = "root";

            // Mysql password for the above username
            $mysql["password"] = "";

            define("SERVER_INSTALLED",true);
            define( "ENABLE_MD5", 0 );

        ?>