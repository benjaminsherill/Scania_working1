<?php
/**
 * Created by PhpStorm.
 * User: PUPILEE
 * Date: 10/11/2018
 * Time: 10:29 AM
 * This is a install home page. Just call view.php to view controls to input from user -
 * address, name, password and so on.
 */
require("view.php");